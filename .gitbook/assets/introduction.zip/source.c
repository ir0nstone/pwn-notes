// gcc source.c -o vuln -no-pie -fno-stack-protector -z execstack

#include <stdio.h>

void main() {
    char buffer[40];
    
    puts("Overflow me");
    gets(buffer);
}