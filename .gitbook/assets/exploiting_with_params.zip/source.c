//gcc source.c -o vuln-32 -no-pie -fno-stack-protector -m32
//gcc source.c -o vuln-64 -no-pie -fno-stack-protector

#include <stdio.h>

void vuln() {
    char buffer[40];
    puts("Overflow Me");
    gets(buffer);
}

int main() {
    vuln();
}

void flag(int check, int check2) {
    if(check == 0xdeadc0de && check2 == 0xc0ded00d) {
        puts("Got it!");
    }
}